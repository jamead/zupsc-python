#!/usr/bin/env python3

import time
import epics
import matplotlib.pyplot as plt

# Normal channel order for writing, printing, and plotting
channels = [1, 2, 3, 4]

# Reverse order for readback test
read_order = [1, 2, 3, 4]

start = 0.0
stop = 1.0
steps = 100
rate_hz = 10.0

period = 1.0 / rate_hz


# --------------------------------------------------
# Create EPICS PV connections
# --------------------------------------------------

set_pvs = {}
read_pvs = {}

for ch in channels:

    set_pvs[ch] = epics.PV(
        f"lab{{1}}Chan{ch}:DAC_SetPt-SP"
    )

    read_pvs[ch] = epics.PV(
        f"lab{{1}}Chan{ch}:DAC-I"
    )


# --------------------------------------------------
# Wait for all PVs to connect
# --------------------------------------------------

print("Connecting to PVs...")

for ch in channels:

    if not set_pvs[ch].wait_for_connection(timeout=2.0):
        raise RuntimeError(
            f"Could not connect to {set_pvs[ch].pvname}"
        )

    if not read_pvs[ch].wait_for_connection(timeout=2.0):
        raise RuntimeError(
            f"Could not connect to {read_pvs[ch].pvname}"
        )

print("All PVs connected.")
print(f"Readback order = {read_order}")


# --------------------------------------------------
# Storage
# --------------------------------------------------

times = []

setpoints = {
    ch: [] for ch in channels
}

readbacks = {
    ch: [] for ch in channels
}


# --------------------------------------------------
# Run ramp
# --------------------------------------------------

t0 = time.monotonic()

for i in range(steps + 1):

    # Scheduled time for this point
    target_time = t0 + i * period

    sleep_time = target_time - time.monotonic()

    if sleep_time > 0:
        time.sleep(sleep_time)


    # Ramp value
    setpoint = start + (stop - start) * i / steps


    # --------------------------------------------------
    # Write all four channels
    # --------------------------------------------------

    for ch in channels:
        set_pvs[ch].put(
            setpoint,
            wait=False
        )


    # Allow PSC/IOC readback to update
    time.sleep(0.03)


    # Give Channel Access a chance to process traffic
    epics.poll(
        evt=0.001,
        iot=0.001
    )


    # --------------------------------------------------
    # Read all four channels in reverse order
    # --------------------------------------------------

    channel_readbacks = {}

    for ch in read_order:

        value = read_pvs[ch].get(
            timeout=0.05,
            use_monitor=False
        )

        channel_readbacks[ch] = value


    # --------------------------------------------------
    # Record data
    # --------------------------------------------------

    elapsed = time.monotonic() - t0

    times.append(elapsed)

    print(
        f"\nTime = {elapsed:7.4f} s   "
        f"Target = {i * period:7.4f} s"
    )

    for ch in channels:

        setpoints[ch].append(setpoint)
        readbacks[ch].append(channel_readbacks[ch])

        print(
            f"Chan{ch}:  "
            f"Setpoint = {setpoint:8.5f}   "
            f"Readback = {channel_readbacks[ch]:8.5f}"
        )


# --------------------------------------------------
# Plot
# --------------------------------------------------

fig, axes = plt.subplots(
    2, 2,
    figsize=(12, 8),
    sharex=True,
    sharey=True
)

axes = axes.flatten()

for i, ch in enumerate(channels):

    ax = axes[i]

    ax.plot(
        times,
        setpoints[ch],
        "o-",
        markersize=3,
        label="Setpoint"
    )

    ax.plot(
        times,
        readbacks[ch],
        "o-",
        markersize=3,
        label="Readback"
    )

    ax.set_title(f"Channel {ch}")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("DAC Value")
    ax.grid(True)
    ax.legend()


fig.suptitle(
    "DAC Setpoint vs Readback - 20 Hz Ramp",
    fontsize=14
)

plt.tight_layout()
plt.show()
